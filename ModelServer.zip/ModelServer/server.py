import grpc
from concurrent import futures

from deeppavlov import build_model, configs
import torch
import torchvision

import QA_pb2
import QA_pb2_grpc


class QAServiceServicer(QA_pb2_grpc.QAServiceServicer):
    model = build_model(configs.squad.squad_bert, download=True)

    def Ask(self, request, context):
        text = [request.text]
        question = [request.question]
        result = self.model(text, question)

        reply = QA_pb2.QAResponse()
        reply.answer = result[0][0]
        return reply


def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    QA_pb2_grpc.add_QAServiceServicer_to_server(QAServiceServicer(), server)
    server.add_insecure_port('localhost:50051')
    server.start()
    print("Waiting")
    server.wait_for_termination()


if __name__ == '__main__':
    serve()
